(* input: sommet             *)
(* output: liste des voisins *)
let voisins_de sommet graph=

(*            TODO           *)










(* TEST FONCTIONEL*)

let graph =
    [ ("a", "b"), 4;
      ("a", "c"), 3;
      ("a", "e"), 7;
      ("b", "c"), 6;
      ("b", "d"), 5;
      ("b", "a"), 4;
      ("c", "d"), 11;
      ("c", "e"), 8;
      ("c", "b"), 6;
      ("c", "a"), 3;
      ("d", "e"), 2;
      ("d", "f"), 2;
      ("d", "g"), 10;
      ("d", "b"), 5;
      ("d", "c"), 11;
      ("e", "g"), 5;
      ("e", "a"), 7;
      ("e", "c"), 8;
      ("e", "d"), 2;
      ("f", "d"), 2;
      ("f", "g"), 3; ];;

let voisins = voisins_de "e" graph;;

print_endline (String.concat ", " voisins)


