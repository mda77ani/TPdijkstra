(* Bibliothèque nécessaire: List *)
(* Fonctions nécessaires: List.fold_left, List.mem *)

(* input: graphe             *)
(* output: liste des sommets *)
let lister_sommets graphe =

(*           TODO            *)










(* TEST FONCTIONEL*)

let () =
  let graph =
      [ ("a", "b"), 4;
        ("a", "c"), 3;
        ("a", "e"), 7;
        ("b", "c"), 6;
        ("b", "d"), 5;
        ("b", "a"), 4;
        ("c", "d"), 11;
        ("c", "e"), 8;
        ("c", "b"), 6;
        ("c", "a"), 3;
        ("d", "e"), 2;
        ("d", "f"), 2;
        ("d", "g"), 10;
        ("d", "b"), 5;
        ("d", "c"), 11;
        ("e", "g"), 5;
        ("e", "a"), 7;
        ("e", "c"), 8;
        ("e", "d"), 2;
        ("f", "d"), 2;
        ("f", "g"), 3; ]

  in
  let sommets = lister_sommets graph in

  print_endline (String.concat ", " sommets)