let lister_sommets graphe =
  (*        TODO         *)

 
let voisin_de sommet graph=
  (*        TODO         *)


 
let retirer_sommet sommet liste =
  (*        TODO         *)







(* input:  liste des voisins                      *)
(* input:  liste des distances depuis l'origine   *)
(* output: sommet et sa distance                  *)
let sommet_suivant q dist =
  match q with
  | [] -> assert false
  | x::xs ->
      let rec aux_f distance v = function
      | x::xs ->
          let d = Hashtbl.find dist x in
          if d < distance
          then aux_f d x xs
          else aux_f distance v xs
      | [] -> (v, distance)
      in
      aux_f (Hashtbl.find dist x) x xs
 

let dijkstra max_val zero add graph source target =
  let vertices = lister_sommets graph in
  let dist_between u v =                    (* Fonction locale                              *)
    try List.assoc (u, v) graph 
    with _ -> zero
  in

  let dist = Hashtbl.create 1 in
  let previous = Hashtbl.create 1 in
  List.iter (fun v ->                       (* Initialisation du tableau des distances      *)
    Hashtbl.add dist v max_val              (* Distance infinie pour tous les sommets, sauf *)
  ) vertices;                               (*                                              *)
  Hashtbl.replace dist source zero;         (* le sommet de de départ (dist: 0)             *)

  let rec loop = function [] -> ()          (* Loop est appliquée à liste des sommets       *)
  | q ->                                         
      let u, dist_u =                                          
        sommet_suivant q dist in            (* Sommet voisin dans [q] ayant la plus petite  *) 
      if dist_u = max_val then              (* distance dans [dist]                         *)
        failwith "aucun sommets n'est atteignable !"; 
      if u = target then () else begin
        let q = retirer_sommet u q in
        List.iter (fun (v, d) ->            (* Boucle sur la liste des voisins v de 'u'     *)
          if List.mem v q then begin  
            let alt = add dist_u (dist_between u v) in
            let dist_v = Hashtbl.find dist v in
            if alt < dist_v then begin      (* Si la dist(u) + cout(u,v) < dist(v)          *)
              Hashtbl.replace dist v alt;      
              Hashtbl.replace previous v u; (* Remplacer le sommet 'v' par 'u'              *)
                                            (* 'u' est sur le chemin optimal                *)
            end
          end
        ) (voisin_de u graph);
        loop q
      end
  in
  loop vertices;

                                             (* Recuperation du chemin optimal               *)
  let s = ref [] in
  let u = ref target in
  while Hashtbl.mem previous !u do
    s := !u :: !s;
    u := Hashtbl.find previous !u
  done;
  (source :: !s)
 
let () =
  let graph =
    [ ("a", "b"), 4;
      ("a", "c"), 3;
      ("a", "e"), 7;
      ("b", "c"), 6;
      ("b", "d"), 5;
      ("b", "a"), 4;
      ("c", "d"), 11;
      ("c", "e"), 8;
      ("c", "b"), 6;
      ("c", "a"), 3;
      ("d", "e"), 2;
      ("d", "f"), 2;
      ("d", "g"), 10;
      ("d", "b"), 5;
      ("d", "c"), 11;
      ("e", "g"), 5;
      ("e", "a"), 7;
      ("e", "c"), 8;
      ("e", "d"), 2;
      ("f", "d"), 2;
      ("f", "g"), 3; ]
  in
  let p = dijkstra max_int 0 (+) graph "a" "f" in
  print_endline (String.concat " ==> " p)