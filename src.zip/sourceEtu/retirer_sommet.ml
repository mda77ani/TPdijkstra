(* input: sommet, liste             *)
(* output: liste sans le sommet     *)
let retirer_sommet sommet liste =

(*              TODO                *)






(* TEST FONCTIONEL*)

let liste=["g"; "f"; "d"; "e"; "c"; "a"; "b"] 

let a_retirer="a"

let liste_paritelle = retirer_sommet a_retirer liste 

